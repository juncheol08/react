import React from 'react'

const About = () => {
  return (
    <div>
        <h2>소개 페이지</h2>
        <p>리액트 라우터 소개</p>
    </div>
  )
}

export default About