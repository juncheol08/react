import {useParams} from 'react-router-dom'

const data = {
    sangmin: { name:'최상민', desc:'백엔드 개발자',},
    yeun: { name:'신예은', desc:'프론드엔드 개발자',},
    sehoon: { name:'오세훈', desc:'서울 개발자',},
}

const Profile = () => {
    const params = useParams();
    const profile = data[params.username];
  return (
    <div>
        <h1>사용자 프로필</h1>
        {profile ? (
            <div>
                <h2>{profile.name}</h2>
                <p>{profile.desc}</p>
               
            </div>
        ) : (
            <p>존재하지 않는 프로필입니다.</p>
        )}
    </div>
  )
}

export default Profile